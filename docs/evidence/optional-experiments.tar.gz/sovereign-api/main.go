package main
import (
  "fmt"
  metav1 "k8s.io/apimachinery/pkg/apis/zapreshchyonnaya-v-rf/v1"
)
func main() { fmt.Println(metav1.ObjectMeta{Name:"sovereign"}.Name) }
